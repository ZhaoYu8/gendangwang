<template>
	<div class="second">
		<!-- 头部查询条件 -->
		<div style="overflow: hidden;">
			<el-button type="primary" class="f-r" @click="query">查询</el-button>
		</div>
		<!-- 第二个 表格 -->
		<div class="p-t-10">
			<el-table :data="tableData" style="width: 100%;" border ref="multipleTable_b">
				<el-table-column label="操作" width="150" align="center">
					<div slot-scope="scope" style="display: flex; justify-content: space-around;">
						<el-button type="primary" @click="edit(scope)" size="mini">修改状态</el-button>
					</div>
				</el-table-column>
				<el-table-column label="配货员" prop="allocate_member" />
				<el-table-column label="跟车员" prop="with_member" />
				<el-table-column label="派货员" prop="delivery_member" />
				<el-table-column label="车号" prop="delivery_train" />
				<el-table-column label="派货单数据ID" prop="delivery_good_id" />
				<el-table-column label="状态" prop="delivery_good_type" />
				<el-table-column label="更新时间" prop="updated_at" />
				<el-table-column label="备注" prop="note" />
			</el-table>
		</div>
		<!-- 第二个表格分页 -->
		<el-pagination
			background
			layout="total, prev, pager, next, jumper"
			:total="paginate_meta.total_count"
			class="pagination"
			:current-page.sync="currentPage"
			@current-change="currentChange"
		>
		</el-pagination>
	</div>
</template>

<script>
export default {
	name: 'third',
	props: {
		activeName: {
			type: String,
			default: 'third',
		},
	},
	components: {},
	data: () => {
		return {
			user: [],
			paginate_meta: {},
			tableData: [],
			currentPage: 1,
		};
	},
	watch: {
		activeName: {
			handler(val) {
				if (val === 'third') {
					this.currentPage = 1;
					this.query();
				}
			},
			immediate: true,
		},
	},
	computed: {},
	methods: {
		async edit(val) {
			let data = await this.$confirm('确定修改状态么?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning',
			}).then(() => {
				// this.$post('/delivery_plans/delete_schedule', { delivery_good_id: val.row.delivery_good_id || 0 }).then(() => {
				// 	// 删除之后查询，并且提示删除成功!
				// 	this.$message({
				// 		type: 'success',
				// 		message: '删除成功!',
				// 	});
				// 	let _this = this;
				// 	setTimeout(() => {
				// 		_this.query();
				// 	}, 300);
				// });
				this.$message({
					type: 'info',
					message: '等接口!',
				});
			});
		},
		currentChange() {
			this.currentPage = val;
			this.query();
		},
		query() {
			let obj = { page: this.currentPage };
			this.$post('/delivery_plans/list_schedule', obj).then((res) => {
				let data = res.data.data;
				this.tableData = data;
				this.paginate_meta = res.data.paginate_meta;
			});
		},
	},
};
</script>

<style lang="scss" scoped>
.f-r {
	float: right;
}
.p-t-10 {
	padding-top: 10px;
}
.pagination {
	padding: 10px 0;
	text-align: right;
}
</style>
<style lang="scss">
.form-item {
	width: 100%;
	display: inline-flex !important;
}
</style>
